function img_r=same_dim(imagen_g)


img_r=imresize(imagen_g,[42 24]);
